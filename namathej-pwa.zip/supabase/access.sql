-- =====================================================================
-- نماذج المساءلة — إدارة الحسابات (مدير النظام، التفعيل، الاشتراك)
-- يُشغَّل بعد schema.sql
-- =====================================================================

-- ---------- بريد مدير النظام ----------
create table if not exists public.app_admin_emails (email text primary key);
alter table public.app_admin_emails enable row level security;          -- بلا سياسات: لا يصل إليها أي مستخدم
insert into public.app_admin_emails (email) values ('k4044s@gmail.com') on conflict do nothing;

-- ---------- صلاحية كل مدرسة ----------
create table if not exists public.school_access (
  user_id     uuid primary key references auth.users(id) on delete cascade,
  status      text not null default 'active' check (status in ('active', 'disabled')),
  plan        text not null default 'trial'  check (plan in ('trial', 'paid')),
  expires_at  date,                                   -- فارغ = بلا نهاية
  note        text,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
alter table public.school_access enable row level security;
drop policy if exists "read own access" on public.school_access;
create policy "read own access" on public.school_access for select to authenticated
  using (user_id = (select auth.uid()));
revoke all on public.school_access from anon;
grant select on public.school_access to authenticated;

drop trigger if exists touch_school_access on public.school_access;
create trigger touch_school_access before update on public.school_access
  for each row execute function public.touch_updated_at();

-- ---------- دوال التحقق ----------
create or replace function public.ksa_today() returns date
language sql stable set search_path = '' as $$ select (now() at time zone 'Asia/Riyadh')::date $$;

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from auth.users u join public.app_admin_emails e on lower(e.email) = lower(u.email)
    where u.id = auth.uid()
  )
$$;

create or replace function public.has_access() returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from public.school_access a
    where a.user_id = auth.uid() and a.status = 'active'
      and (a.expires_at is null or a.expires_at >= public.ksa_today())
  )
$$;

-- ---------- عند إنشاء حساب: السماح بحسابات التطبيق فقط + شهر تجريبي ----------
create or replace function public.on_new_user() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  if lower(new.email) like '%@users.namathej.app' then
    insert into public.school_access (user_id, status, plan, expires_at)
    values (new.id, 'active', 'trial', public.ksa_today() + 30)
    on conflict (user_id) do nothing;
  elsif not exists (select 1 from public.app_admin_emails e where lower(e.email) = lower(new.email)) then
    raise exception 'التسجيل متاح من التطبيق فقط';
  end if;
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.on_new_user();

-- ---------- البيانات تتطلب حساباً مفعّلاً ساري الاشتراك ----------
drop policy if exists "own school" on public.schools;
create policy "own school" on public.schools for all to authenticated
  using (id = (select auth.uid()) and (select public.has_access()))
  with check (id = (select auth.uid()) and (select public.has_access()));

do $$ declare t text; begin
  foreach t in array array['employees','log_entries','actions_issued','deductions_raised'] loop
    execute format('drop policy if exists "own rows" on public.%s', t);
    execute format('create policy "own rows" on public.%s for all to authenticated using (school_id = (select auth.uid()) and (select public.has_access())) with check (school_id = (select auth.uid()) and (select public.has_access()))', t);
  end loop;
end $$;

-- ---------- دوال مدير النظام ----------
drop function if exists public.admin_list();
create function public.admin_list()
returns table (user_id uuid, username text, email text, school text, created_at timestamptz, last_sign_in_at timestamptz,
               status text, plan text, expires_at date, employees bigint, logs bigint,
               creator text, civil text, mobile text)
language plpgsql stable security definer set search_path = '' as $$
begin
  if not public.is_admin() then raise exception 'غير مصرّح'; end if;
  return query
    select u.id, coalesce(u.raw_user_meta_data->>'username', split_part(u.email, '@', 1)), u.email::text,
           coalesce(s.name, u.raw_user_meta_data->>'school'), u.created_at, u.last_sign_in_at,
           a.status, a.plan, a.expires_at,
           (select count(*) from public.employees e where e.school_id = u.id),
           (select count(*) from public.log_entries l where l.school_id = u.id),
           u.raw_user_meta_data->>'creator', u.raw_user_meta_data->>'civil', u.raw_user_meta_data->>'mobile'
    from auth.users u
    join public.school_access a on a.user_id = u.id
    left join public.schools s on s.id = u.id
    order by u.created_at desc;
end $$;

create or replace function public.admin_set_status(p_uid uuid, p_status text) returns void
language plpgsql security definer set search_path = '' as $$
begin
  if not public.is_admin() then raise exception 'غير مصرّح'; end if;
  update public.school_access set status = p_status where user_id = p_uid;
end $$;

create or replace function public.admin_set_expiry(p_uid uuid, p_date date) returns void
language plpgsql security definer set search_path = '' as $$
begin
  if not public.is_admin() then raise exception 'غير مصرّح'; end if;
  update public.school_access set expires_at = p_date, plan = 'paid', status = 'active' where user_id = p_uid;
end $$;

create or replace function public.admin_set_password(p_uid uuid, p_password text) returns void
language plpgsql security definer set search_path = '' as $$
begin
  if not public.is_admin() then raise exception 'غير مصرّح'; end if;
  if length(coalesce(p_password, '')) < 8 then raise exception 'كلمة المرور 8 أحرف على الأقل'; end if;
  if not exists (select 1 from public.school_access where user_id = p_uid) then raise exception 'الحساب غير موجود'; end if;
  update auth.users set encrypted_password = extensions.crypt(p_password, extensions.gen_salt('bf')), updated_at = now()
  where id = p_uid;
end $$;

create or replace function public.admin_delete(p_uid uuid) returns void
language plpgsql security definer set search_path = '' as $$
begin
  if not public.is_admin() then raise exception 'غير مصرّح'; end if;
  if not exists (select 1 from public.school_access where user_id = p_uid) then raise exception 'الحساب غير موجود'; end if;
  delete from auth.users where id = p_uid;
end $$;

-- الصلاحيات: للمستخدمين المسجّلين فقط (والتحقق من المدير داخل كل دالة)
revoke execute on function public.is_admin(), public.has_access(), public.admin_list(), public.admin_set_status(uuid, text),
  public.admin_set_expiry(uuid, date), public.admin_set_password(uuid, text), public.admin_delete(uuid) from public, anon;
grant execute on function public.is_admin(), public.has_access(), public.admin_list(), public.admin_set_status(uuid, text),
  public.admin_set_expiry(uuid, date), public.admin_set_password(uuid, text), public.admin_delete(uuid) to authenticated;
