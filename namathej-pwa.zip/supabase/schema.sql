-- =====================================================================
-- نماذج المساءلة والإجراءات — قاعدة البيانات (Supabase / PostgreSQL)
-- كل مدرسة = حساب واحد (auth.users). كل صف مربوط بالمدرسة عبر school_id،
-- وسياسات RLS تمنع أي مدرسة من رؤية بيانات مدرسة أخرى.
-- =====================================================================

-- ---------- المدارس (الإعدادات) ----------
create table if not exists public.schools (
  id          uuid primary key default auth.uid() references auth.users(id) on delete cascade,
  name        text,
  edu         text,
  gender      text,
  principal   text,
  settings    jsonb not null default '{}'::jsonb,   -- كل إعدادات المدرسة (hf.set)
  prefs       jsonb not null default '{}'::jsonb,   -- تفضيلات الواجهة (آخر نموذج...)
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

-- ---------- الموظفون ----------
create table if not exists public.employees (
  school_id   uuid not null default auth.uid() references public.schools(id) on delete cascade,
  id          text not null,
  civil       text,
  name        text not null,
  role        text,
  active      boolean,
  data        jsonb not null,                       -- السجل الكامل كما في التطبيق
  updated_at  timestamptz not null default now(),
  primary key (school_id, id)
);
create index if not exists employees_civil_idx on public.employees (school_id, civil);

-- ---------- سجل الغياب والتأخر والانصراف ----------
create table if not exists public.log_entries (
  school_id   uuid not null default auth.uid() references public.schools(id) on delete cascade,
  id          text not null,
  form        text,                                 -- absence / latedep / nocheck ...
  emp_key     text,
  emp_name    text,
  entry_date  date,
  late_mins   integer,
  early_mins  integer,
  gone_mins   integer,
  data        jsonb not null,
  updated_at  timestamptz not null default now(),
  primary key (school_id, id)
);
create index if not exists log_entries_date_idx on public.log_entries (school_id, entry_date);
create index if not exists log_entries_emp_idx  on public.log_entries (school_id, emp_key);

-- ---------- الإجراءات المنفّذة (درجات سلّم الإجراءات) ----------
create table if not exists public.actions_issued (
  school_id   uuid not null default auth.uid() references public.schools(id) on delete cascade,
  id          text not null,
  emp_key     text,
  emp_name    text,
  tier        integer,
  minutes     integer,
  action_date date,
  data        jsonb not null,
  updated_at  timestamptz not null default now(),
  primary key (school_id, id)
);

-- ---------- أيام الحسم المرفوعة ----------
create table if not exists public.deductions_raised (
  school_id   uuid not null default auth.uid() references public.schools(id) on delete cascade,
  id          text not null,
  emp_key     text,
  kind        text,
  days        numeric,
  raised_date date,
  data        jsonb not null,
  updated_at  timestamptz not null default now(),
  primary key (school_id, id)
);

-- ---------- تحديث updated_at تلقائياً ----------
create or replace function public.touch_updated_at() returns trigger
language plpgsql set search_path = '' as $$
begin new.updated_at = now(); return new; end $$;

do $$ declare t text; begin
  foreach t in array array['schools','employees','log_entries','actions_issued','deductions_raised'] loop
    execute format('drop trigger if exists touch_%1$s on public.%1$s', t);
    execute format('create trigger touch_%1$s before update on public.%1$s for each row execute function public.touch_updated_at()', t);
  end loop;
end $$;

-- ---------- الأمان: كل مدرسة ترى بياناتها فقط ----------
alter table public.schools           enable row level security;
alter table public.employees         enable row level security;
alter table public.log_entries       enable row level security;
alter table public.actions_issued    enable row level security;
alter table public.deductions_raised enable row level security;

drop policy if exists "own school" on public.schools;
create policy "own school" on public.schools for all to authenticated
  using (id = (select auth.uid())) with check (id = (select auth.uid()));

do $$ declare t text; begin
  foreach t in array array['employees','log_entries','actions_issued','deductions_raised'] loop
    execute format('drop policy if exists "own rows" on public.%s', t);
    execute format('create policy "own rows" on public.%s for all to authenticated using (school_id = (select auth.uid())) with check (school_id = (select auth.uid()))', t);
  end loop;
end $$;

-- لا صلاحيات للزائر غير المسجّل
revoke all on public.schools, public.employees, public.log_entries, public.actions_issued, public.deductions_raised from anon;
grant select, insert, update, delete on public.schools, public.employees, public.log_entries, public.actions_issued, public.deductions_raised to authenticated;
