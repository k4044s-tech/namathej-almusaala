-- =====================================================================
-- نماذج المساءلة — ملاحظات إدارية (مشروع Supabase: namathej)
-- الإدارة اليومية تتم من «شاشة مدير النظام» داخل التطبيق:
--   ادخل ببريدك k4044s@gmail.com وكلمة مرورك بدل اسم المستخدم.
-- ترتيب ملفات القاعدة: schema.sql ثم access.sql (نُفّذا مسبقاً).
-- =====================================================================

-- إضافة مدير نظام آخر (ينشئ حسابه من Authentication > Users > Add user):
-- insert into public.app_admin_emails (email) values ('other@example.com');

-- قائمة المدارس مع حالتها
select u.raw_user_meta_data->>'username' as username, s.name as school,
       a.status, a.plan, a.expires_at, u.created_at, u.last_sign_in_at
from auth.users u join public.school_access a on a.user_id = u.id
left join public.schools s on s.id = u.id
order by u.created_at desc;

-- تغيير مدة الفترة التجريبية للحسابات الجديدة (الافتراضي 30 يوماً):
-- عدّل الرقم 30 في الدالة public.on_new_user داخل access.sql ثم أعد تشغيلها.
